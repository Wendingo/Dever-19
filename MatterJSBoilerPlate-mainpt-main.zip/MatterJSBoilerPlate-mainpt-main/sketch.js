const Engine = Matter.Engine;
const World = Matter.World;
const Bodies = Matter.Bodies;

let engine;
let world;

var options;

var ball, square, rectangle;
var ground;
var left;
var right;
var top_wall;

function setup() {
  createCanvas(400,400);
  engine = Engine.create();
  world = engine.world;
  options = {restituition:0.95};
  
  ball = Bodies.circle(200, 100, 20, options);
  square = Bodies.rectangle(100, 50, 50, 50, options);
  rectangle = Bodies.rectangle(300, 50, 75, 50, options);

  World.add(world, ball);
  World.add(world, square);
  World.add(world, rectangle);
  
  ground = new Ground(200,390,400,20);
  right = new Ground(390,200,20,400);
  left = new Ground(10,200,20,400);
  top_wall = new Ground(200,10,400,20);

  rectMode(CENTER);
  ellipseMode(RADIUS);
}

function draw() 
{
  background(100);

  ellipse(ball.position.x, ball.position.y, 20);
  rect(square.position.x, square.position.y, 50, 50);
  rect(rectangle.position.x, rectangle.position.y, 75, 25);

  ground.show();
  top_wall.show();
  left.show();
  right.show();
  Engine.update(engine);
}